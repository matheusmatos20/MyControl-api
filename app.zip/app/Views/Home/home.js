// Aqui você pode colocar todo JS do dashboard
// Exemplo: interações de cards, gráficos, etc.

console.log("Dashboard carregado com sucesso!");
